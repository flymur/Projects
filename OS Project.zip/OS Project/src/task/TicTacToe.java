package task;

import main.Process;

public class TicTacToe extends Process{


 //   private static TicControl tic = new TicControl();


    public TicTacToe(int a) {
        pcb.setPid("pid"+a);
        pcb.setAppName("Tic Tac Toe");
        pcb.setMemorySize(50);
        pcb.setRomSize(50);
        pcb.setProcessType("game");
        pcb.setStatus("Running");
    }


}
